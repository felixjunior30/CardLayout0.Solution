﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.Entity;

namespace CardLayout0.Models
{
    public class Content
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Telefono { get; set; }
        public DateTime Fecha_Nac { get; set; } 
        public int edad { get; set; }




    }
}
