﻿using CardLayout0.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace CardLayout0.Controllers
{
    public class Controlador : Controller
    {
       

        public IActionResult Index()
        {
            string connectionString = "Data Source=VMSVRSQLDEV01;Initial Catalog=Pasantias;Integrated Security=True";

                List<Content> lobj = new List<Content>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM ExaPasantia";
                

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Content obj = new Content();
                            obj.Nombre = reader.GetString(0);
                            obj.Apellido = reader.GetString(1);
                            obj.Telefono = reader.GetString(2);
                            obj.edad =reader.GetInt32(3);
                            obj.Fecha_Nac = reader.GetDateTime(4);

                            lobj.Add(obj);
                        }
                    }
                }
            }
                   

            return View(lobj);
        }
    }
}

